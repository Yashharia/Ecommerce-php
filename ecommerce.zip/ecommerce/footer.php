<!DOCTYPE html>
<html>
<head>
	<title>Eppareles</title>
	<meta charset="utf-8">
	
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Epparels</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	
	
	
	<link href="./css/style.css" rel="stylesheet">

	<title></title>
</head>
<body>
<footer>
    <div class="container footer-container">
       <div class="row">
       
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <ul class="contact">
                         <span>Categories</span>    
                         <a href="mens-products.php"><li>
                            Mens
                          </li>
                        </a>
                        
                        <a href="womens-products.php">       
                          <li>
                            Womens
                          </li>
                          </a>
                     </ul>
                </div>
                
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <ul class="contact">
                         <span>Contact</span>    
                         <li>
                            <a href="#">care@m-eretail.com</a>
                          </li>
                         <li>
                            1234567890
                          </li>      
                         

                    </ul>
                </div>
                
                
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <ul class="contact">
                         <span>Brands</span>    
                         <li>
                            <a href="#">Brand 1</a>
                          </li>
                               
                          <li>
                             <a href="#">Brand 2</a>
                          </li>
                               
                          <li>
                            <a href="#">Brand 3</a>
                          </li>
                               
                          <li>
                             <a href="#">Brand 4</a>
                          </li>
                               
                          <li>
                            <a href="#">Brand 5</a>
                         </li>
                    </ul>
                </div>
           
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                   <ul class="contact">
                              <span>NEED HELP?</span>    
                              
                               <li>
                                    <a href="#">Track Order</a>
                               </li>
                                
                               <li>
                                    <a href="#">Returns Policy</a>
                               </li>
                               
                               <li>
                                    <a href="#">Cancellation</a>
                               </li>
                                
                               <li>
                                    <a href="#">Shipping Information</a>
                              </li>
                              <li>
                                    <a href="#">FAQs</a>
                              </li>
                              <li>
                                    <a href="#">Terms and Conditions</a>
                              </li>
                              <li>
                                    <a href="#">Privacy Policy</a>
                              </li>

                              
                     </ul>
               </div>
           </div>
           </body>
           </html>