<?php
$user='root';
$pass='';
$db='epparels';
$link =new mysqli('localhost', $user, $pass,$db)or die("unable");
?>
