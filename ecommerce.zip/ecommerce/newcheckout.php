
<?php include 'connection.php';?>
<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
</head>



<body>
	<?php include 'header.php';?>
	<?php
	if(isset($_SESSION['username'])){
	$uname= $_SESSION["username"];
	echo $uname;
	}
	?>
	<div class="container padding">
        <div class="row register-form">
        <div class="col-xs-6">
        	<div class="panel text-center">
        		<div class="panel-heading">
        			<h3> Register</h3>
			 			</div>
			 			<div class="panel-body">
			    		<form action="" role="form" method="post">
			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			                <input type="text" name="name" id="name" class="form-control input-sm" placeholder="First Name">
			    					</div>
			    				</div>
			    			</div>

			    			<div class="form-group">
			    				<input type="email" name="email" id="email" class="form-control input-sm" placeholder="Email Address">
			    			</div>

			    			<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<input type="text" name="address" id="address" class="form-control input-sm" placeholder="Address">
			    					</div>
			    				</div>
			    				
			    			</div>
			    			
			    			<input type="submit" name="submit-register"value="Register" class="btn btn-info btn-block">
			    		
			    		</form>
			    	</div>
	    		</div>
    		</div>
    	</div>
    </div>
      <?php
							if (isset($_POST['submit-register'])) {
									$firstname=$_POST['name'];
									
									$email=$_POST['email'];
									$pass=$_POST['address'];
									$runorder="insert into checkout(uid,name,email,address) value('$uname','$firstname','$email','$pass')";

									if(mysqli_query($link,$runorder))
									{
										echo "<script>alert('Data saved')</script>";
										/*echo "<script>window.location='thankyou.php'</script>";*/
									}   
									else 
									{
									    echo "<script>alert('Data not saved')</script>";                          	# code...
									}                              
								    }                         
							?> 
	<?php include 'footer.php';?>

</body>
</html>